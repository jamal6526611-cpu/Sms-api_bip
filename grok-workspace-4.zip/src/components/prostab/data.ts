export const MUSIC_URL =
  "https://www.image2url.com/r2/default/audio/1794939349211-69983499-8cc0-4ebf-82d5-e678af08c120.mp3";

/** Measured length of the provided track; replaced by audio.duration when known. */
export const AUDIO_FALLBACK_DURATION = 39.079;

export const LYRIC_TIMING = {
  lead: 0.06,
  tail: 0.1,
};

export const LYRICS = [
  { startTime: 1.53, text: "গুনে গুনে দেখি অবেলার স্বপ্নটাই, আঁকা ছিল কত শত কবিতায়।" },
  { startTime: 6.27, text: "স্বপ্নের সেই কবিতার ছন্দতে মিশে ছিল তার হাসি মাখা ছবিটা," },
  { startTime: 11.67, text: "যা আঁকা ছিল অদ্ভুত রঙকুলি। যা জমা থাকে আমার মন" },
  { startTime: 15.87, text: "মাঝে, বর হয়ে আমি চড়ছি ঘোড়ায়, আড়ালে তুমি লুকিয়ে আছো" },
  { startTime: 20.79, text: "গৌর সাজে। আমার এই স্বপ্ন কি শুধু স্বপ্ন হয়ে হাসাবে" },
  { startTime: 26.01, text: "আমায়? তেমন সাহস নেই আমার তোমাকে কীভাবে প্রস্তাব জানাই? আমার" },
  { startTime: 32.43, text: "এই স্বপ্ন কি শুধু স্বপ্ন হয়ে হাসাবে আমায়? তেমন সাহস" },
  { startTime: 38.55, text: "নেই আমার।" },
] as const;

export const SCENES = [
  { id: "eye", start: 0, title: "চোখ", trans: "fade", ken: "in" },
  { id: "bedroom", start: 1.53, title: "ঘর", trans: "zoom", ken: "left" },
  { id: "writing", start: 4, title: "লেখা", trans: "ink", ken: "in" },
  { id: "letter", start: 6.27, title: "কবিতা", trans: "paper", ken: "none" },
  { id: "portrait", start: 11.67, title: "ছবি", trans: "light", ken: "in" },
  { id: "dream", start: 13.9, title: "স্বপ্ন", trans: "parallax", ken: "none" },
  { id: "wedding", start: 15.87, title: "ঘোড়া", trans: "fade", ken: "left" },
  { id: "bride", start: 18.4, title: "কনে", trans: "curtain", ken: "in" },
  { id: "return", start: 20.79, title: "ফিরে আসা", trans: "blur", ken: "in" },
  { id: "meeting", start: 26.01, title: "দেখা", trans: "parallax", ken: "none" },
  { id: "rose", start: 29.4, title: "গোলাপ", trans: "zoom", ken: "in" },
  { id: "together", start: 32.43, title: "একসাথে", trans: "light", ken: "in" },
  { id: "finale", start: 38.55, title: "চিঠি", trans: "paper", ken: "none" },
] as const;

export type SceneId = (typeof SCENES)[number]["id"];
export type SceneDef = (typeof SCENES)[number];

export function isPaperScene(id: SceneId) {
  return id === "writing" || id === "letter" || id === "finale";
}

export function sceneIndexAt(t: number) {
  let idx = 0;
  for (let i = 0; i < SCENES.length; i++) {
    if (t >= SCENES[i].start) idx = i;
  }
  return idx;
}

export function lyricIndexAt(t: number) {
  let idx = -1;
  for (let i = 0; i < LYRICS.length; i++) {
    if (t >= LYRICS[i].startTime) idx = i;
  }
  return idx;
}

export function segmentEnd(index: number, duration: number) {
  if (index < 0) return 0;
  if (index < LYRICS.length - 1) return LYRICS[index + 1].startTime;
  return Math.max(duration, LYRICS[index].startTime + 0.4);
}

export function activeWordIndex(text: string, start: number, end: number, t: number) {
  const words = text.split(/\s+/).filter(Boolean);
  const span = Math.max(0.05, end - start);
  const lead = span * LYRIC_TIMING.lead;
  const usable = Math.max(0.05, span * (1 - LYRIC_TIMING.lead - LYRIC_TIMING.tail));
  const p = Math.min(0.999, Math.max(0, (t - start - lead) / usable));
  return { words, index: Math.min(words.length - 1, Math.floor(p * words.length)) };
}

export function bnDigits(n: number) {
  return String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)] ?? d);
}

export function formatTime(t: number) {
  if (!Number.isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}
