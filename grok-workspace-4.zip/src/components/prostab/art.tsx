import type { ReactNode } from "react";
import type { SceneId } from "@/components/prostab/data";

const HEX = {
  navy: "#10182B",
  navy2: "#1A2744",
  burgundy: "#672D43",
  rose: "#C98C9B",
  ivory: "#F7EBDD",
  gold: "#D6B477",
  lavender: "#B9A8CE",
  skin: "#E4B08A",
  skinDeep: "#C4845C",
  hair: "#1B1322",
  ink: "#3A2430",
  leaf: "#2F4A3C",
  leafSoft: "#4E6B58",
  roseDeep: "#8C243C",
  paper: "#FBF6EE",
  horse: "#F6F1E8",
  wood: "#6A4038",
  woodLite: "#8A5648",
  lip: "#A85C68",
  night: "#0C1222",
};

function Frame({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <svg className="art-svg" viewBox="0 0 900 1600" preserveAspectRatio="xMidYMid slice" role="img" aria-label={label}>
      {children}
    </svg>
  );
}

function Boy({
  outfit = "kurta",
  gaze = 0,
  tilt = 0,
}: {
  outfit?: "kurta" | "sherwani";
  gaze?: number;
  tilt?: number;
}) {
  return (
    <g transform={`rotate(${tilt} 100 170)`}>
      <g className="anim sway">
        {outfit === "sherwani" && (
          <g>
            <path d="M62 86 L100 4 L138 86 Z" fill={HEX.ivory} stroke={HEX.gold} strokeWidth="3" />
            <path d="M74 84 L100 24 L126 84" fill="none" stroke={HEX.gold} strokeWidth="1.6" />
            <circle cx="100" cy="46" r="3.2" fill={HEX.gold} />
            <circle cx="88" cy="62" r="2" fill={HEX.gold} />
            <circle cx="112" cy="62" r="2" fill={HEX.gold} />
          </g>
        )}
        <path
          d="M40 128 C32 70 58 42 100 40 C146 42 170 74 162 130 C156 104 136 88 100 86 C64 88 48 106 40 128 Z"
          fill={HEX.hair}
        />
        <ellipse cx="46" cy="140" rx="11" ry="15" fill={HEX.skinDeep} />
        <ellipse cx="154" cy="140" rx="11" ry="15" fill={HEX.skinDeep} />
        <path d="M82 176 L118 176 L124 206 L76 206 Z" fill={HEX.skinDeep} />
        <ellipse cx="100" cy="136" rx="54" ry="64" fill={HEX.skin} />
        <path d="M48 118 C62 62 140 58 154 118 C132 98 114 112 100 102 C82 114 66 100 48 118 Z" fill={HEX.hair} />
        <path d="M46 122 C32 150 40 180 58 170 C50 148 52 132 46 122 Z" fill={HEX.hair} />
        <path d="M154 122 C168 150 160 180 142 170 C150 148 148 132 154 122 Z" fill={HEX.hair} />
        <path d="M66 116 Q82 106 96 116" fill="none" stroke={HEX.hair} strokeWidth="3.2" strokeLinecap="round" />
        <path d="M104 116 Q118 106 134 116" fill="none" stroke={HEX.hair} strokeWidth="3.2" strokeLinecap="round" />
        <g className="anim blink">
          <ellipse cx="78" cy="134" rx="13" ry="8.5" fill={HEX.ivory} />
          <ellipse cx="122" cy="134" rx="13" ry="8.5" fill={HEX.ivory} />
          <g className="anim gaze">
            <circle cx={78 + gaze} cy="135" r="5.2" fill="#3A261C" />
            <circle cx={122 + gaze} cy="135" r="5.2" fill="#3A261C" />
            <circle cx={80 + gaze} cy="133" r="1.7" fill={HEX.ivory} />
            <circle cx={124 + gaze} cy="133" r="1.7" fill={HEX.ivory} />
          </g>
        </g>
        <path d="M100 140 Q107 156 100 164" fill="none" stroke={HEX.skinDeep} strokeWidth="2.5" strokeLinecap="round" />
        <path d="M84 172 Q100 184 116 172 Q100 176 84 172 Z" fill={HEX.lip} />
        <ellipse cx="68" cy="162" rx="11" ry="6" fill={HEX.rose} opacity="0.35" />
        <ellipse cx="132" cy="162" rx="11" ry="6" fill={HEX.rose} opacity="0.35" />
        <circle cx="60" cy="158" r="2.3" fill="#6E3A38" />
        {outfit === "kurta" ? (
          <g>
            <path d="M26 208 L76 196 L100 240 L124 196 L174 208 L194 390 L6 390 Z" fill={HEX.ivory} />
            <path d="M76 198 L100 246 L124 198" fill="none" stroke={HEX.gold} strokeWidth="3" />
            <path d="M16 386 H184" stroke={HEX.gold} strokeWidth="5" />
          </g>
        ) : (
          <g>
            <path d="M24 206 L74 194 L100 236 L126 194 L176 206 L196 400 L4 400 Z" fill={HEX.burgundy} />
            <path d="M100 240 V392" stroke={HEX.gold} strokeWidth="2" />
            {[262, 290, 318, 346].map((y) => (
              <circle key={y} cx="100" cy={y} r="4" fill={HEX.gold} />
            ))}
            <path d="M48 214 L100 248 L152 214" fill="none" stroke={HEX.gold} strokeWidth="3" />
            <path d="M34 268 Q100 304 166 268" fill="none" stroke={HEX.gold} strokeWidth="8" strokeLinecap="round" />
            <path d="M56 220 Q100 268 144 220" fill="none" stroke={HEX.ivory} strokeWidth="9" strokeLinecap="round" />
          </g>
        )}
      </g>
    </g>
  );
}

function Girl({ outfit = "portrait" }: { outfit?: "portrait" | "bride" }) {
  const saree = outfit === "bride" ? HEX.roseDeep : HEX.rose;
  const deep = outfit === "bride" ? "#5C1828" : "#A86D7E";
  return (
    <g className="anim sway">
      <path
        d="M36 168 C16 90 52 34 100 32 C156 34 186 96 166 176 C178 270 172 360 150 460 L50 460 C30 350 24 260 36 168 Z"
        fill={HEX.hair}
      />
      {outfit === "bride" && (
        <path d="M18 130 Q100 -10 182 130 L220 470 L-20 470 Z" fill={HEX.roseDeep} opacity="0.42" />
      )}
      <ellipse cx="44" cy="162" rx="11" ry="16" fill={HEX.skinDeep} />
      <ellipse cx="156" cy="162" rx="11" ry="16" fill={HEX.skinDeep} />
      <circle cx="42" cy="184" r="4.5" fill={HEX.gold} />
      <circle cx="158" cy="184" r="4.5" fill={HEX.gold} />
      <path d="M84 196 L116 196 L122 224 L78 224 Z" fill={HEX.skinDeep} />
      <ellipse cx="100" cy="154" rx="54" ry="66" fill={HEX.skin} />
      <path d="M46 136 C60 58 142 52 156 134 C134 108 114 124 100 112 C82 126 64 110 46 136 Z" fill={HEX.hair} />
      <path d="M44 132 C30 186 38 250 62 268 C50 200 48 160 44 132 Z" fill={HEX.hair} />
      <path d="M156 132 C170 186 162 250 138 268 C150 200 152 160 156 132 Z" fill={HEX.hair} />
      <circle cx="100" cy="112" r="3.4" fill={HEX.roseDeep} />
      {outfit === "bride" && (
        <g>
          <path d="M100 62 V108" stroke={HEX.gold} strokeWidth="2" />
          <path d="M100 58 L90 78 L110 78 Z" fill={HEX.gold} />
          <circle cx="100" cy="84" r="3" fill={HEX.gold} />
        </g>
      )}
      <path d="M64 132 Q80 122 94 132" fill="none" stroke={HEX.hair} strokeWidth="3" strokeLinecap="round" />
      <path d="M106 132 Q120 122 136 132" fill="none" stroke={HEX.hair} strokeWidth="3" strokeLinecap="round" />
      <g className="anim blink">
        <ellipse cx="78" cy="150" rx="13" ry="8.5" fill={HEX.ivory} />
        <ellipse cx="122" cy="150" rx="13" ry="8.5" fill={HEX.ivory} />
        <g className="anim gaze">
          <circle cx="78" cy="151" r="5.2" fill="#3A261C" />
          <circle cx="122" cy="151" r="5.2" fill="#3A261C" />
          <circle cx="80" cy="149" r="1.7" fill={HEX.ivory} />
          <circle cx="124" cy="149" r="1.7" fill={HEX.ivory} />
        </g>
      </g>
      <path d="M100 156 Q108 172 100 180" fill="none" stroke={HEX.skinDeep} strokeWidth="2.4" strokeLinecap="round" />
      <circle cx="90" cy="176" r="3.3" fill="none" stroke={HEX.gold} strokeWidth="1.6" />
      <path d="M84 190 Q100 202 116 190 Q100 194 84 190 Z" fill={HEX.lip} />
      <ellipse cx="66" cy="180" rx="11" ry="6" fill={HEX.rose} opacity="0.38" />
      <ellipse cx="134" cy="180" rx="11" ry="6" fill={HEX.rose} opacity="0.38" />
      <path d="M68 226 Q100 258 132 226" fill="none" stroke={HEX.gold} strokeWidth="3.2" />
      <circle cx="100" cy="252" r="5.5" fill={HEX.gold} />
      {outfit === "bride" && (
        <g>
          <circle cx="86" cy="240" r="3" fill={HEX.gold} />
          <circle cx="114" cy="240" r="3" fill={HEX.gold} />
        </g>
      )}
      <path d="M20 246 L74 224 L100 262 L126 224 L180 246 L204 500 L-4 500 Z" fill={saree} />
      <path d="M-4 500 L46 330 L78 500 Z" fill={deep} />
      <path d="M180 270 Q110 360 16 300" fill="none" stroke={HEX.gold} strokeWidth="7" />
      <path d="M4 490 H196" stroke={HEX.gold} strokeWidth="7" />
      {outfit === "bride" && (
        <g>
          <path d="M40 470 Q70 430 55 400" fill="none" stroke={HEX.gold} strokeWidth="3" />
          <path d="M150 470 Q130 420 150 390" fill="none" stroke={HEX.gold} strokeWidth="3" />
        </g>
      )}
    </g>
  );
}

function Flower({
  x,
  y,
  s = 1,
  petal = HEX.rose,
}: {
  x: number | string;
  y: number | string;
  s?: number | string;
  petal?: string;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse key={a} cx="0" cy="-9" rx="5.5" ry="9" fill={petal} transform={`rotate(${a})`} />
      ))}
      <circle r="3.4" fill={HEX.gold} />
    </g>
  );
}

function Stars() {
  const pts = [
    [80, 120],
    [160, 220],
    [740, 160],
    [820, 280],
    [120, 380],
    [800, 460],
    [200, 90],
    [680, 80],
    [400, 150],
    [500, 240],
  ];
  return (
    <g fill={HEX.ivory}>
      {pts.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i % 3 === 0 ? 2.2 : 1.3} opacity={0.55 + (i % 4) * 0.1} />
      ))}
    </g>
  );
}

function EyeScene() {
  const lashes = Array.from({ length: 16 }, (_, i) => {
    const t = i / 15;
    const x = 150 + t * 600;
    const y = 690 - Math.sin(Math.PI * t) * 168;
    const rot = -55 + t * 110;
    return { x, y, rot };
  });
  return (
    <Frame label="চোখের কাছের দৃশ্য">
      <defs>
        <radialGradient id="eye-bg" cx="50%" cy="46%" r="60%">
          <stop offset="0%" stopColor="#24345A" />
          <stop offset="55%" stopColor={HEX.navy} />
          <stop offset="100%" stopColor={HEX.night} />
        </radialGradient>
        <radialGradient id="iris" cx="42%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#C9894A" />
          <stop offset="35%" stopColor="#7A4A28" />
          <stop offset="78%" stopColor="#3A2418" />
          <stop offset="100%" stopColor="#1A100C" />
        </radialGradient>
        <clipPath id="iris-clip">
          <circle cx="450" cy="760" r="148" />
        </clipPath>
      </defs>
      <rect width="900" height="1600" fill="url(#eye-bg)" />
      <g className="anim blink" style={{ transformOrigin: "450px 760px" }}>
        <path d="M120 760 Q450 500 780 760 Q450 1020 120 760 Z" fill={HEX.ivory} />
        <circle cx="450" cy="760" r="156" fill="url(#iris)" />
        <g clipPath="url(#iris-clip)">
          <rect x="330" y="680" width="240" height="150" fill="#15203A" />
          <rect x="360" y="700" width="70" height="90" fill="#0E1730" stroke={HEX.gold} strokeWidth="2" />
          <circle cx="500" cy="730" r="18" fill={HEX.ivory} />
          <circle cx="500" cy="730" r="28" fill={HEX.gold} opacity="0.25" />
          <circle cx="390" cy="800" r="6" fill={HEX.ivory} />
          <circle cx="430" cy="804" r="6" fill={HEX.rose} />
        </g>
        <circle cx="450" cy="760" r="62" fill={HEX.night} />
        <circle cx="402" cy="724" r="22" fill={HEX.ivory} opacity="0.85" />
        <circle cx="488" cy="800" r="8" fill={HEX.ivory} opacity="0.35" />
        <path d="M120 760 Q450 500 780 760" fill="none" stroke={HEX.skin} strokeWidth="28" />
        <path d="M140 790 Q450 1040 760 790" fill="none" stroke={HEX.skinDeep} strokeWidth="16" />
        {lashes.map((l, i) => (
          <line
            key={i}
            x1={l.x}
            y1={l.y}
            x2={l.x}
            y2={l.y - 34}
            stroke={HEX.hair}
            strokeWidth="3.4"
            strokeLinecap="round"
            transform={`rotate(${l.rot} ${l.x} ${l.y})`}
          />
        ))}
      </g>
      <ellipse cx="450" cy="1180" rx="260" ry="40" fill={HEX.gold} opacity="0.08" />
    </Frame>
  );
}

function Bedroom({ moonlit = false }: { moonlit?: boolean }) {
  const pid = moonlit ? "back" : "room";
  return (
    <Frame label={moonlit ? "ছেলেটি আবার খাতার দিকে তাকিয়ে আছে" : "মাঝরাতে ছেলেটির ঘর"}>
      <defs>
        <linearGradient id={`${pid}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={moonlit ? "#0E1830" : "#15233F"} />
          <stop offset="100%" stopColor={HEX.navy} />
        </linearGradient>
        <linearGradient id={`${pid}-light`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={HEX.gold} stopOpacity="0.55" />
          <stop offset="100%" stopColor={HEX.gold} stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect width="900" height="1600" fill={`url(#${pid}-sky)`} />
      <rect y="1280" width="900" height="320" fill="#241820" />
      <Stars />
      {moonlit && <polygon points="520,180 760,1500 300,1500" fill={HEX.ivory} opacity="0.08" />}
      <g>
        <rect x="250" y="120" width="400" height="460" rx="18" fill="#0E1730" stroke={HEX.wood} strokeWidth="14" />
        <path d="M450 134 V566 M264 350 H636" stroke={HEX.woodLite} strokeWidth="6" />
        <circle cx="450" cy="300" r="64" fill={HEX.ivory} />
        <circle cx="478" cy="286" r="58" fill="#101C36" opacity="0.25" />
        <circle cx="450" cy="300" r="110" fill={HEX.gold} opacity="0.13" />
      </g>
      <g>
        <rect x="36" y="180" width="150" height="640" rx="8" fill="#3A282C" />
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <rect
            key={i}
            x={52 + (i % 2) * 8}
            y={210 + i * 96}
            width={110 - (i % 3) * 10}
            height="78"
            rx="3"
            fill={[HEX.burgundy, HEX.gold, HEX.rose, HEX.lavender, HEX.ivory, HEX.roseDeep][i]}
          />
        ))}
      </g>
      <g transform="translate(250 470) scale(1.62)">
        <Boy gaze={moonlit ? -4 : -2} tilt={8} />
      </g>
      <rect x="40" y="1088" width="820" height="80" rx="10" fill={HEX.woodLite} />
      <rect x="20" y="1155" width="860" height="460" fill={HEX.wood} />
      <g transform="translate(250 1020)">
        <rect width="360" height="230" rx="8" fill={HEX.paper} />
        <path d="M180 0 V230" stroke={HEX.rose} strokeWidth="2" />
        {[40, 78, 116, 154, 192].map((y) => (
          <path key={y} d={`M28 ${y} H160 M200 ${y} H332`} stroke={HEX.lavender} strokeWidth="2" opacity="0.8" />
        ))}
      </g>
      <g transform="translate(640 900)">
        <path d="M70 40 L120 200 H20 Z" fill={HEX.ivory} />
        <rect x="58" y="200" width="24" height="90" fill={HEX.gold} />
        <rect x="40" y="286" width="60" height="12" rx="3" fill={HEX.gold} />
        <path d="M70 40 L210 360 L-40 420 Z" fill={`url(#${pid}-light)`} />
      </g>
      <circle cx="140" cy="1040" r="26" fill={HEX.burgundy} />
      <rect x="128" y="1064" width="24" height="30" fill={HEX.gold} />
    </Frame>
  );
}

function WritingScene() {
  return (
    <Frame label="খাতায় কবিতা লেখা হচ্ছে">
      <rect width="900" height="1600" fill={HEX.wood} />
      <rect x="40" y="180" width="820" height="1180" rx="18" fill={HEX.paper} />
      <path d="M450 180 V1360" stroke={HEX.rose} strokeWidth="3" opacity="0.7" />
      {[280, 360, 440, 520, 600, 680, 760, 840, 920, 1000, 1080].map((y) => (
        <path key={y} d={`M90 ${y} H410 M490 ${y} H810`} stroke="#E4D3C4" strokeWidth="3" />
      ))}
      <g className="ink-lines" fill="none" stroke={HEX.ink} strokeWidth="3.2" strokeLinecap="round">
        <path className="inkstroke" d="M110 360 C180 350 240 372 320 358" />
        <path className="inkstroke d2" d="M110 440 C200 430 260 454 380 442" />
        <path className="inkstroke d3" d="M110 520 C190 508 250 530 300 516" />
      </g>
      <g className="anim pen-hand">
        <path d="M520 430 C560 390 640 360 700 390 C760 430 780 520 720 560 C660 590 560 540 530 480 Z" fill={HEX.skin} />
        <path d="M690 400 C740 370 790 390 770 450 C750 500 700 490 690 450 Z" fill={HEX.skinDeep} />
        <rect x="470" y="470" width="150" height="14" rx="4" fill={HEX.navy} transform="rotate(-38 545 477)" />
        <path d="M452 548 L478 522 L492 536 L466 564 Z" fill={HEX.gold} />
        <path d="M760 470 C820 450 860 500 820 540 L760 500 Z" fill={HEX.ivory} />
      </g>
      <Flower x="120" y="180" s="1.4" />
      <Flower x="760" y="1240" s="1.6" petal={HEX.roseDeep} />
    </Frame>
  );
}

function LetterScene() {
  return (
    <Frame label="হাতের লেখা চিঠি">
      <rect width="900" height="1600" fill={HEX.navy} />
      <rect x="48" y="70" width="804" height="1460" rx="8" fill={HEX.paper} />
      <rect x="68" y="90" width="764" height="1420" fill="none" stroke={HEX.gold} strokeWidth="2" />
      <Flower x="120" y="160" s="1.8" />
      <Flower x="760" y="200" s="1.3" petal={HEX.lavender} />
      <Flower x="150" y="1380" s="1.5" petal={HEX.roseDeep} />
      <Flower x="740" y="1340" s="1.7" />
      <path d="M160 230 H740" stroke={HEX.gold} strokeWidth="1.5" opacity="0.7" />
      <path d="M200 1280 H700" stroke={HEX.rose} strokeWidth="1.5" opacity="0.8" />
    </Frame>
  );
}

function PortraitScene() {
  return (
    <Frame label="তার আঁকা প্রতিকৃতি">
      <defs>
        <radialGradient id="port-bg" cx="50%" cy="40%" r="70%">
          <stop offset="0%" stopColor="#4A3040" />
          <stop offset="100%" stopColor={HEX.navy} />
        </radialGradient>
      </defs>
      <rect width="900" height="1600" fill="url(#port-bg)" />
      <rect x="115" y="210" width="670" height="1040" rx="12" fill={HEX.gold} />
      <rect x="145" y="240" width="610" height="980" fill={HEX.burgundy} />
      <rect x="175" y="270" width="550" height="900" fill="#F3E4D4" />
      <g transform="translate(250 360) scale(1.85)">
        <Girl outfit="portrait" />
      </g>
      {[0, 1, 2, 3].map((i) => (
        <g key={i} className="anim petal" style={{ animationDelay: `${i * 0.8}s` }}>
          <ellipse cx={180 + i * 160} cy={240} rx="10" ry="16" fill={i % 2 ? HEX.rose : HEX.ivory} opacity="0.85" />
        </g>
      ))}
    </Frame>
  );
}

function DreamScene() {
  return (
    <Frame label="স্বপ্নের আলো">
      <defs>
        <linearGradient id="dream" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2A2148" />
          <stop offset="50%" stopColor="#672D43" />
          <stop offset="100%" stopColor="#10182B" />
        </linearGradient>
        <linearGradient id="rib" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={HEX.gold} stopOpacity="0" />
          <stop offset="50%" stopColor={HEX.ivory} stopOpacity="0.85" />
          <stop offset="100%" stopColor={HEX.rose} stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect width="900" height="1600" fill="url(#dream)" />
      <circle cx="450" cy="420" r="180" fill={HEX.lavender} opacity="0.25" />
      <circle cx="450" cy="420" r="90" fill={HEX.ivory} opacity="0.2" />
      <g className="anim layer-a" fill="none" stroke="url(#rib)" strokeLinecap="round">
        <path d="M-40 360 C 180 240 300 520 940 300" strokeWidth="26" />
        <path d="M-40 980 C 220 860 420 1200 960 900" strokeWidth="18" />
      </g>
      <g className="anim layer-b" fill="none" stroke={HEX.rose} strokeLinecap="round" opacity="0.55">
        <path d="M-20 640 C 240 480 400 860 940 620" strokeWidth="20" />
        <path d="M40 200 C 260 360 500 80 880 260" strokeWidth="12" />
      </g>
      <g className="anim layer-c">
        {Array.from({ length: 14 }, (_, i) => (
          <circle
            key={i}
            cx={80 + ((i * 67) % 760)}
            cy={180 + ((i * 97) % 1100)}
            r={4 + (i % 4) * 3}
            fill={i % 2 ? HEX.gold : HEX.ivory}
            opacity="0.35"
          />
        ))}
      </g>
      <g transform="translate(250 1180) scale(0.9)" opacity="0.9">
        <circle cx="70" cy="40" r="26" fill={HEX.hair} />
        <path d="M40 70 L100 70 L120 160 L20 160 Z" fill={HEX.ivory} />
        <circle cx="190" cy="36" r="26" fill={HEX.hair} />
        <path d="M150 68 L230 68 L250 160 L140 160 Z" fill={HEX.rose} />
      </g>
    </Frame>
  );
}

function WeddingScene() {
  return (
    <Frame label="সাদা ঘোড়ায় বর">
      <rect width="900" height="1600" fill={HEX.navy} />
      <Stars />
      <path d="M0 1180 Q450 1080 900 1180 V1600 H0 Z" fill="#241820" />
      {Array.from({ length: 8 }, (_, i) => (
        <g key={i}>
          <circle cx={70 + i * 110} cy={150 + (i % 2) * 18} r="6" fill={HEX.gold} />
          <path d={`M${70 + i * 110} 156 V230`} stroke={HEX.gold} strokeWidth="1.4" opacity="0.7" />
        </g>
      ))}
      <path d="M40 250 Q200 300 360 250 Q520 200 700 260 Q820 290 880 250" fill="none" stroke={HEX.roseDeep} strokeWidth="16" />
      {[120, 220, 320, 430, 540, 650, 760].map((x, i) => (
        <Flower key={x} x={x} y={250 + (i % 2) * 16} s="0.9" petal={i % 2 ? HEX.roseDeep : HEX.ivory} />
      ))}
      <g transform="translate(40 980)">
        <ellipse cx="420" cy="250" rx="280" ry="26" fill="#000" opacity="0.28" />
        <g className="anim leg">
          <rect x="210" y="150" width="26" height="130" rx="12" fill={HEX.horse} />
        </g>
        <g className="anim leg b">
          <rect x="270" y="150" width="26" height="130" rx="12" fill="#E7E0D6" />
        </g>
        <g className="anim leg">
          <rect x="520" y="146" width="26" height="130" rx="12" fill={HEX.horse} />
        </g>
        <g className="anim leg b">
          <rect x="580" y="146" width="26" height="130" rx="12" fill="#E7E0D6" />
        </g>
        <ellipse cx="400" cy="120" rx="230" ry="86" fill={HEX.horse} />
        <path d="M560 90 C680 40 760 -20 730 -70 C780 -10 800 30 760 70 C710 90 640 100 590 110" fill={HEX.horse} />
        <ellipse cx="760" cy="-78" rx="42" ry="30" fill={HEX.horse} />
        <circle cx="776" cy="-86" r="5" fill={HEX.hair} />
        <path d="M720 -50 C690 10 640 50 590 60" fill="none" stroke={HEX.gold} strokeWidth="5" />
        <path d="M180 70 Q90 0 140 -60 Q190 10 230 60" fill="#EFE6DA" />
        <path d="M250 40 H560" stroke={HEX.burgundy} strokeWidth="18" />
        <path d="M280 40 Q400 100 540 40" fill="none" stroke={HEX.gold} strokeWidth="5" />
        <g transform="translate(300 -150) scale(0.78)">
          <Boy outfit="sherwani" />
        </g>
      </g>
    </Frame>
  );
}

function BrideScene() {
  return (
    <Frame label="লাল শাড়িতে কনে">
      <defs>
        <radialGradient id="bride-bg" cx="50%" cy="42%" r="65%">
          <stop offset="0%" stopColor="#4A2434" />
          <stop offset="100%" stopColor={HEX.night} />
        </radialGradient>
      </defs>
      <rect width="900" height="1600" fill="url(#bride-bg)" />
      {Array.from({ length: 7 }, (_, i) => (
        <circle key={i} cx={80 + i * 120} cy="120" r="7" fill={HEX.gold} />
      ))}
      <Flower x="120" y="220" s="1.5" petal={HEX.roseDeep} />
      <Flower x="760" y="240" s="1.4" />
      <g transform="translate(230 340) scale(2.15)">
        <Girl outfit="bride" />
      </g>
      <rect className="curtain-l" x="0" y="0" width="470" height="1600" fill={HEX.burgundy} />
      <rect className="curtain-r" x="430" y="0" width="470" height="1600" fill="#542538" />
      <path className="curtain-l" d="M0 0 H470 V80 Q240 140 0 70 Z" fill={HEX.gold} opacity="0.85" />
      <path className="curtain-r" d="M430 0 H900 V70 Q670 150 430 80 Z" fill={HEX.gold} opacity="0.85" />
    </Frame>
  );
}

function MeetingScene() {
  return (
    <Frame label="বাগানে দুজনের দেখা">
      <defs>
        <linearGradient id="day" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F3E2C8" />
          <stop offset="45%" stopColor="#E7C6C4" />
          <stop offset="100%" stopColor={HEX.lavender} />
        </linearGradient>
      </defs>
      <rect width="900" height="1600" fill="url(#day)" />
      <circle cx="700" cy="220" r="70" fill={HEX.ivory} />
      <circle cx="700" cy="220" r="120" fill={HEX.gold} opacity="0.25" />
      <path d="M0 620 L180 430 L340 560 L520 360 L700 540 L900 400 V760 H0 Z" fill="#8E7E9A" opacity="0.85" />
      <path d="M0 700 L220 520 L420 660 L640 480 L900 640 V820 H0 Z" fill="#6E5E78" />
      <g className="anim layer-b">
        <circle cx="90" cy="860" r="120" fill={HEX.leaf} />
        <circle cx="200" cy="800" r="90" fill={HEX.leafSoft} />
        <rect x="120" y="900" width="26" height="180" fill="#3A2A22" />
        <circle cx="800" cy="840" r="130" fill={HEX.leaf} />
        <circle cx="690" cy="800" r="80" fill={HEX.leafSoft} />
        <rect x="760" y="900" width="26" height="200" fill="#3A2A22" />
      </g>
      <path d="M280 1600 L380 980 H520 L620 1600 Z" fill="#C4B09A" />
      <path d="M330 1600 L410 1040 H490 L570 1600 Z" fill="#E6D3BC" />
      <g transform="translate(40 980) scale(1.15)">
        <g className="anim walker-l">
          <Boy gaze={4} />
        </g>
      </g>
      <g transform="translate(470 980) scale(1.15)">
        <g className="anim walker-r">
          <Girl outfit="portrait" />
        </g>
      </g>
      {[0, 1, 2, 3, 4].map((i) => (
        <g key={i} className="anim leaf" style={{ animationDelay: `${i * 0.6}s` }}>
          <ellipse cx={160 + i * 140} cy="200" rx="12" ry="7" fill={HEX.gold} />
        </g>
      ))}
    </Frame>
  );
}

function RoseScene() {
  return (
    <Frame label="হাতে একটি লাল গোলাপ">
      <defs>
        <radialGradient id="garden" cx="50%" cy="40%" r="70%">
          <stop offset="0%" stopColor="#6E8A6A" />
          <stop offset="100%" stopColor="#1C3328" />
        </radialGradient>
      </defs>
      <rect width="900" height="1600" fill="url(#garden)" />
      {[
        [140, 280, 90],
        [680, 360, 120],
        [200, 640, 70],
        [720, 700, 100],
        [120, 980, 80],
        [760, 1100, 90],
      ].map(([x, y, r], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill={HEX.ivory} opacity="0.08" />
      ))}
      <g transform="translate(450 640)">
        {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
          <ellipse key={a} cx="0" cy="-34" rx="22" ry="40" fill={HEX.roseDeep} transform={`rotate(${a})`} />
        ))}
        {[20, 70, 130, 190, 250, 310].map((a) => (
          <ellipse key={a} cx="0" cy="-20" rx="16" ry="28" fill="#B4334C" transform={`rotate(${a})`} />
        ))}
        <circle r="16" fill="#6E182C" />
        <path d="M0 70 C 30 180 10 300 0 430" fill="none" stroke={HEX.leaf} strokeWidth="10" strokeLinecap="round" />
        <path d="M10 200 C 80 180 90 250 20 250" fill={HEX.leafSoft} />
        <path d="M-4 280 C -80 250 -90 330 -10 330" fill={HEX.leaf} />
      </g>
      <g transform="translate(300 1080)">
        <g className="anim sway">
          <path
            d="M150 80 C90 40 40 80 50 150 C20 140 0 190 40 230 C10 250 30 310 90 300 C100 350 180 350 190 290 C250 300 270 230 220 200 C250 140 200 80 150 80 Z"
            fill={HEX.skin}
          />
          <path d="M70 150 C30 130 10 180 46 214 C60 190 66 170 70 150 Z" fill={HEX.skinDeep} />
        </g>
      </g>
      {[0, 1, 2].map((i) => (
        <g key={i} className="anim petal" style={{ animationDelay: `${i * 1.1}s` }}>
          <ellipse cx={180 + i * 220} cy="180" rx="14" ry="22" fill={HEX.roseDeep} />
        </g>
      ))}
    </Frame>
  );
}

function TogetherScene() {
  return (
    <Frame label="একসাথে, বিয়ের সাজে">
      <rect width="900" height="1600" fill={HEX.navy} />
      <Stars />
      {Array.from({ length: 10 }, (_, i) => (
        <circle
          key={i}
          cx={60 + (i % 5) * 180}
          cy={140 + Math.floor(i / 5) * 70}
          r={5 + (i % 3)}
          fill={HEX.gold}
          opacity="0.85"
        />
      ))}
      <path d="M120 260 Q450 80 780 260" fill="none" stroke={HEX.gold} strokeWidth="4" />
      {[180, 280, 380, 480, 580, 680].map((x, i) => (
        <Flower key={x} x={x} y={200 + (i % 2) * 24} s="1.1" petal={i % 2 ? HEX.roseDeep : HEX.ivory} />
      ))}
      <ellipse cx="450" cy="1320" rx="280" ry="40" fill="#000" opacity="0.28" />
      <g transform="translate(80 620) scale(1.45)">
        <Boy outfit="sherwani" gaze={3} />
      </g>
      <g transform="translate(400 600) scale(1.5)">
        <Girl outfit="bride" />
      </g>
      <path d="M300 1120 Q450 1160 600 1100" fill="none" stroke={HEX.ivory} strokeWidth="8" strokeLinecap="round" opacity="0.8" />
    </Frame>
  );
}

function FinaleScene() {
  return (
    <Frame label="শেষ চিঠি">
      <rect width="900" height="1600" fill={HEX.navy} />
      <rect x="40" y="48" width="820" height="1504" rx="10" fill={HEX.paper} />
      <rect x="60" y="68" width="780" height="1464" fill="none" stroke={HEX.gold} strokeWidth="1.6" />
      <Flower x="110" y="130" s="1.3" />
      <Flower x="790" y="150" s="1.1" petal={HEX.lavender} />
    </Frame>
  );
}

const SCENE_VIEW: Record<SceneId, () => ReactNode> = {
  eye: () => <EyeScene />,
  bedroom: () => <Bedroom />,
  writing: () => <WritingScene />,
  letter: () => <LetterScene />,
  portrait: () => <PortraitScene />,
  dream: () => <DreamScene />,
  wedding: () => <WeddingScene />,
  bride: () => <BrideScene />,
  return: () => <Bedroom moonlit />,
  meeting: () => <MeetingScene />,
  rose: () => <RoseScene />,
  together: () => <TogetherScene />,
  finale: () => <FinaleScene />,
};

export function SceneArt({ id }: { id: SceneId }) {
  const View = SCENE_VIEW[id];
  return <View />;
}

export function SealMark({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 120 120" aria-hidden>
      <circle cx="60" cy="60" r="54" fill={HEX.burgundy} />
      <circle cx="60" cy="60" r="46" fill="none" stroke={HEX.gold} strokeWidth="2" />
      <circle cx="60" cy="60" r="40" fill="none" stroke={HEX.gold} strokeWidth="1" opacity="0.6" />
      {[0, 60, 120, 180, 240, 300].map((a) => (
        <ellipse key={a} cx="60" cy="42" rx="8" ry="14" fill={HEX.roseDeep} transform={`rotate(${a} 60 60)`} />
      ))}
      <circle cx="60" cy="60" r="7" fill={HEX.gold} />
    </svg>
  );
}

export function EnvelopeArt() {
  return (
    <svg className="envelope-svg" viewBox="0 0 360 250" aria-hidden>
      <defs>
        <linearGradient id="env-paper" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF9F2" />
          <stop offset="100%" stopColor={HEX.ivory} />
        </linearGradient>
      </defs>
      <ellipse className="warm-light" cx="180" cy="150" rx="120" ry="70" fill={HEX.gold} opacity="0" />
      <path d="M30 70 H330 V220 H30 Z" fill="url(#env-paper)" stroke={HEX.gold} strokeWidth="3" />
      <path d="M30 70 L180 160 L330 70" fill={HEX.paper} stroke={HEX.gold} strokeWidth="3" />
      <path className="flap" d="M30 70 L180 168 L330 70 L180 20 Z" fill="#F3E4D2" stroke={HEX.gold} strokeWidth="3" />
      <g className="seal" transform="translate(120 78)">
        <circle cx="60" cy="48" r="36" fill={HEX.burgundy} />
        <circle cx="60" cy="48" r="30" fill="none" stroke={HEX.gold} strokeWidth="2" />
        {[0, 72, 144, 216, 288].map((a) => (
          <ellipse key={a} cx="60" cy="36" rx="6" ry="10" fill={HEX.rose} transform={`rotate(${a} 60 48)`} />
        ))}
        <circle cx="60" cy="48" r="5" fill={HEX.gold} />
      </g>
    </svg>
  );
}
