import { useEffect, useRef, useState, type RefObject } from "react";
import {
  ChevronLeft,
  ChevronRight,
  List,
  Maximize,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { EnvelopeArt, SceneArt, SealMark } from "@/components/prostab/art";
import {
  AUDIO_FALLBACK_DURATION,
  LYRICS,
  MUSIC_URL,
  SCENES,
  activeWordIndex,
  bnDigits,
  formatTime,
  isPaperScene,
  lyricIndexAt,
  sceneIndexAt,
  segmentEnd,
  type SceneId,
} from "@/components/prostab/data";

type Phase = "loading" | "intro" | "story";

type Snap = {
  scene: number;
  lyric: number;
  word: number;
  prevLyric: number;
};

function Dust() {
  return (
    <div className="dust" aria-hidden>
      {Array.from({ length: 16 }, (_, i) => (
        <span
          key={i}
          style={{
            left: `${(i * 17) % 100}%`,
            animationDelay: `${(i % 8) * 0.65}s`,
            animationDuration: `${9 + (i % 5)}s`,
          }}
        />
      ))}
    </div>
  );
}

function Words({ text, active }: { text: string; active: number }) {
  const words = text.split(/\s+/).filter(Boolean);
  return (
    <p className="line">
      {words.map((word, i) => (
        <span key={`${word}-${i}`} className={`word${i <= active ? " is-on" : ""}${i === active ? " is-active" : ""}`}>
          {i > 0 ? " " : ""}
          {word}
        </span>
      ))}
    </p>
  );
}

export function Experience() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const shellRef = useRef<HTMLElement>(null);
  const seekRef = useRef<HTMLInputElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const durRef = useRef<HTMLSpanElement>(null);
  const seekingRef = useRef(false);
  const silentRef = useRef(false);
  const silentT = useRef(0);
  const silentPlaying = useRef(false);
  const playingRef = useRef(false);
  const phaseRef = useRef<Phase>("loading");
  const sceneRef = useRef(0);
  const volumeRef = useRef(0.9);
  const durationRef = useRef(AUDIO_FALLBACK_DURATION);
  const api = useRef({
    togglePlay: () => {},
    goScene: (_i: number) => {},
    nudgeVol: (_d: number) => {},
    toggleMute: () => {},
    toggleFs: () => {},
    replay: () => {},
  });

  const [phase, setPhase] = useState<Phase>("loading");
  const [opening, setOpening] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [snap, setSnap] = useState<Snap>({ scene: 0, lyric: -1, word: 0, prevLyric: -1 });
  const [leaving, setLeaving] = useState<number | null>(null);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.9);
  const [duration, setDuration] = useState(AUDIO_FALLBACK_DURATION);
  const [error, setError] = useState<string | null>(null);
  const [audioBroken, setAudioBroken] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [ended, setEnded] = useState(false);
  const [menu, setMenu] = useState(false);
  const [full, setFull] = useState(false);
  const [loadNote, setLoadNote] = useState("পাতা, কালি, আর গান জড়ো হচ্ছে");

  phaseRef.current = phase;
  playingRef.current = playing;
  sceneRef.current = snap.scene;
  volumeRef.current = volume;
  durationRef.current = duration;

  useEffect(() => {
    const audio = audioRef.current;
    if (audio) audio.volume = 0.9;
    let dead = false;
    const min = new Promise((resolve) => window.setTimeout(resolve, 1300));
    const fonts = document.fonts?.ready ?? Promise.resolve();
    const audioReady = new Promise<void>((resolve) => {
      const node = audioRef.current;
      if (!node) {
        resolve();
        return;
      }
      if (node.readyState >= 1) {
        resolve();
        return;
      }
      const done = () => resolve();
      node.addEventListener("loadedmetadata", done, { once: true });
      node.addEventListener("error", done, { once: true });
      window.setTimeout(done, 5000);
    });
    void Promise.all([min, fonts, audioReady]).then(() => {
      if (!dead) setPhase("intro");
    });
    return () => {
      dead = true;
    };
  }, []);

  useEffect(() => {
    if (durRef.current) durRef.current.textContent = formatTime(duration);
    if (seekRef.current) seekRef.current.max = String(duration);
  }, [duration]);

  useEffect(() => {
    let raf = 0;
    let lastScene = 0;
    let lastLyric = -1;
    let lastWord = 0;
    let lastT = 0;
    let lastStamp = performance.now();

    const loop = () => {
      const now = performance.now();
      const dt = Math.min(0.08, (now - lastStamp) / 1000);
      lastStamp = now;
      let t = 0;
      const audio = audioRef.current;
      if (!silentRef.current && audio) {
        t = audio.currentTime || 0;
        if (Number.isFinite(audio.duration) && audio.duration > 0 && audio.duration !== durationRef.current) {
          durationRef.current = audio.duration;
          setDuration(audio.duration);
        }
      } else {
        if (silentPlaying.current) {
          silentT.current += dt;
          if (silentT.current >= durationRef.current) {
            silentT.current = durationRef.current;
            silentPlaying.current = false;
            setPlaying(false);
            setEnded(true);
          }
        }
        t = silentT.current;
      }

      if (timeRef.current) timeRef.current.textContent = formatTime(t);
      if (seekRef.current && !seekingRef.current) seekRef.current.value = String(t);

      const scene = sceneIndexAt(t);
      const lyric = lyricIndexAt(t);
      let word = 0;
      if (lyric >= 0) {
        const seg = LYRICS[lyric];
        word = activeWordIndex(seg.text, seg.startTime, segmentEnd(lyric, durationRef.current), t).index;
      }
      if (scene !== lastScene || lyric !== lastLyric || word !== lastWord) {
        const jumped = Math.abs(t - lastT) > 0.75;
        const lyricChanged = lyric !== lastLyric;
        lastScene = scene;
        lastLyric = lyric;
        lastWord = word;
        setSnap((current) => ({
          scene,
          lyric,
          word,
          prevLyric: lyricChanged ? (jumped ? -1 : current.lyric) : jumped ? -1 : current.prevLyric,
        }));
      }
      lastT = t;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    if (leaving === null) return;
    const id = window.setTimeout(() => setLeaving(null), 920);
    return () => window.clearTimeout(id);
  }, [leaving]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === " " || e.code === "Space") {
        e.preventDefault();
        api.current.togglePlay();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        api.current.goScene(sceneRef.current + 1);
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        api.current.goScene(sceneRef.current - 1);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        api.current.nudgeVol(0.08);
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        api.current.nudgeVol(-0.08);
      } else if (e.key === "m" || e.key === "M") api.current.toggleMute();
      else if (e.key === "f" || e.key === "F") api.current.toggleFs();
      else if (e.key === "r" || e.key === "R") api.current.replay();
      else if (e.key === "Escape") setMenu(false);
    };
    const onFs = () => setFull(Boolean(document.fullscreenElement));
    window.addEventListener("keydown", onKey);
    document.addEventListener("fullscreenchange", onFs);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("fullscreenchange", onFs);
    };
  }, []);

  const applyTime = (time: number) => {
    const next = Math.max(0, Math.min(time, durationRef.current));
    if (silentRef.current) {
      silentT.current = next;
      return;
    }
    const audio = audioRef.current;
    if (audio) audio.currentTime = next;
  };

  const playAudio = async () => {
    if (silentRef.current) {
      silentPlaying.current = true;
      setPlaying(true);
      setEnded(false);
      setPhase("story");
      return;
    }
    const audio = audioRef.current;
    if (!audio) return;
    try {
      await audio.play();
      setPlaying(true);
      setEnded(false);
      setError(null);
      setPhase("story");
    } catch {
      setError("গান এখন চালানো যায়নি। আবার চাপুন, অথবা গান ছাড়া দেখুন।");
      setPlaying(false);
    }
  };

  const pauseAudio = () => {
    silentPlaying.current = false;
    audioRef.current?.pause();
    setPlaying(false);
  };

  const begin = (at = 0, immediate = false) => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const go = () => {
      setPhase("story");
      applyTime(at);
      void playAudio();
    };
    if (immediate || reduced) {
      go();
      return;
    }
    setOpening(true);
    window.setTimeout(go, 780);
  };

  const togglePlay = () => {
    if (phaseRef.current !== "story") {
      begin(0, phaseRef.current === "loading");
      return;
    }
    if (playingRef.current) pauseAudio();
    else void playAudio();
  };

  const goScene = (index: number) => {
    const clamped = Math.max(0, Math.min(SCENES.length - 1, index));
    if (phaseRef.current === "loading") return;
    setMenu(false);
    if (phaseRef.current !== "story") {
      begin(SCENES[clamped].start, true);
      return;
    }
    applyTime(SCENES[clamped].start);
    setEnded(false);
  };

  const replay = () => {
    setEnded(false);
    setMenu(false);
    if (phaseRef.current === "loading") return;
    applyTime(0);
    void playAudio();
  };

  const nudgeVol = (delta: number) => {
    const next = Math.max(0, Math.min(1, +(volumeRef.current + delta).toFixed(3)));
    setVolume(next);
    volumeRef.current = next;
    if (audioRef.current) {
      audioRef.current.volume = next;
      if (next === 0) audioRef.current.muted = true;
      else audioRef.current.muted = false;
    }
    setMuted(next === 0);
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    const next = !audio?.muted;
    setMuted(next);
    if (audio) audio.muted = next;
  };

  const toggleFs = async () => {
    const el = shellRef.current as (HTMLElement & { webkitRequestFullscreen?: () => void }) | null;
    if (!el) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (el.requestFullscreen) await el.requestFullscreen();
      else el.webkitRequestFullscreen?.();
    } catch {
      setError("ফুলস্ক্রিন এই ব্রাউজারে খুলছে না।");
    }
  };

  api.current = { togglePlay, goScene, nudgeVol, toggleMute, toggleFs, replay };

  const prevSceneRef = useRef(snap.scene);
  useEffect(() => {
    if (prevSceneRef.current !== snap.scene) {
      setLeaving(prevSceneRef.current);
      prevSceneRef.current = snap.scene;
    }
  }, [snap.scene]);

  const scene = SCENES[snap.scene];
  const paper = isPaperScene(scene.id);
  const swipe = useRef<{ x: number; y: number } | null>(null);

  const retryAudio = () => {
    const audio = audioRef.current;
    if (!audio) return;
    silentRef.current = false;
    setAudioBroken(false);
    setError(null);
    setLoadNote("গানটি আবার ডাকা হচ্ছে");
    audio.load();
  };

  const watchSilently = () => {
    silentRef.current = true;
    setAudioBroken(true);
    setError(null);
    begin(phaseRef.current === "story" ? silentT.current : 0, true);
  };

  return (
    <main
      ref={shellRef}
      className={`shell${playing ? "" : " is-paused"}${phase === "story" ? " is-story" : ""}`}
      onPointerDown={(e) => {
        const target = e.target as HTMLElement;
        if (target.closest("button, input, a, .player, .chapters")) return;
        swipe.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerUp={(e) => {
        if (!swipe.current) return;
        const dx = e.clientX - swipe.current.x;
        const dy = e.clientY - swipe.current.y;
        swipe.current = null;
        if (phaseRef.current !== "story") return;
        if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
        goScene(sceneRef.current + (dx < 0 ? 1 : -1));
      }}
    >
      <audio
        ref={audioRef}
        src={MUSIC_URL}
        preload="auto"
        onError={() => {
          setAudioBroken(true);
          silentRef.current = true;
          setError("গানটি লোড করা যায়নি। আবার চেষ্টা করুন, অথবা গান ছাড়া দেখুন।");
        }}
        onWaiting={() => setBuffering(true)}
        onPlaying={() => {
          setBuffering(false);
          setPlaying(true);
        }}
        onPause={() => setPlaying(false)}
        onEnded={() => {
          setPlaying(false);
          setEnded(true);
        }}
        onVolumeChange={(e) => {
          setMuted(e.currentTarget.muted);
          setVolume(e.currentTarget.volume);
          volumeRef.current = e.currentTarget.volume;
        }}
      />

      <aside className="side side-left">
        <p className="brand-mark">PROSTAB</p>
        <p className="brand-ver">2.0</p>
        <span className="gold-rule" />
        <p className="brand-whisper">কিছু অনুভূতি শব্দে প্রকাশ করা যায় না।</p>
      </aside>

      <section className="frame" aria-label="গল্পের মঞ্চ">
        <div className={`stage${playing ? "" : " is-paused"}`}>
          {leaving !== null && leaving !== snap.scene && (
            <article key={`leave-${leaving}`} className="scene is-leaving" data-trans={SCENES[leaving].trans}>
              <div className="art-viewport">
                <SceneArt id={SCENES[leaving].id} />
              </div>
            </article>
          )}
          <article key={scene.id} className="scene is-active" data-trans={scene.trans} data-ken={scene.ken}>
            <div className="art-viewport">
              <SceneArt id={scene.id} />
            </div>
          </article>
          <div key={`sweep-${scene.id}`} className={`sweep sweep-${scene.trans}`} />
        </div>
        <Dust />
        <div className="grain" />
        <div className="vignette" />
        {!paper && phase === "story" && <div className="scrim" />}

        {phase === "story" && (
          <div className="topbar">
            <button type="button" className="icon-btn" aria-label="আগের দৃশ্য" onClick={() => goScene(snap.scene - 1)} disabled={snap.scene === 0}>
              <ChevronLeft />
            </button>
            <p key={scene.id} className="chapter-chip">
              <span>{bnDigits(snap.scene + 1).padStart(2, "০")}</span>
              {scene.title}
            </p>
            <button
              type="button"
              className="icon-btn"
              aria-label="পরের দৃশ্য"
              onClick={() => goScene(snap.scene + 1)}
              disabled={snap.scene === SCENES.length - 1}
            >
              <ChevronRight />
            </button>
            <button type="button" className="icon-btn chap-btn" aria-label="দৃশ্যতালিকা" aria-expanded={menu} onClick={() => setMenu((v) => !v)}>
              {menu ? <X /> : <List />}
            </button>
          </div>
        )}

        {menu && phase === "story" && (
          <nav className="chapters" aria-label="দৃশ্য">
            {SCENES.map((item, i) => (
              <button key={item.id} type="button" className={i === snap.scene ? "is-on" : ""} onClick={() => goScene(i)}>
                <span>{bnDigits(i + 1).padStart(2, "০")}</span>
                {item.title}
              </button>
            ))}
          </nav>
        )}

        {phase === "story" && (
          <StoryLyrics
            sceneId={scene.id}
            lyric={snap.lyric}
            word={snap.word}
            prevLyric={snap.prevLyric}
            ended={ended}
            onReplay={replay}
          />
        )}

        {phase !== "loading" && (
          <Player
            seekRef={seekRef}
            timeRef={timeRef}
            durRef={durRef}
            playing={playing}
            muted={muted}
            volume={volume}
            duration={duration}
            buffering={buffering}
            onSeekStart={() => {
              seekingRef.current = true;
            }}
            onSeek={(value) => applyTime(value)}
            onSeekEnd={() => {
              seekingRef.current = false;
            }}
            onToggle={togglePlay}
            onReplay={replay}
            onMute={toggleMute}
            onVolume={(value) => {
              volumeRef.current = muted ? 0 : volumeRef.current;
              nudgeVol(value - (muted ? 0 : volumeRef.current));
            }}
            onChapters={() => {
              if (phaseRef.current !== "story") begin(0, true);
              setMenu((open) => !open);
            }}
            onFs={() => void toggleFs()}
            full={full}
          />
        )}

        {phase === "intro" && (
          <div className={`intro${opening ? " is-opening" : ""}`}>
            <p className="eyebrow">PROSTAB 2.0</p>
            <div className="envelope-wrap">
              <EnvelopeArt />
            </div>
            <h1>একটি ছোট্ট গল্প...</h1>
            <p className="lede">কিছু অনুভূতি শব্দে প্রকাশ করা যায় না।</p>
            {error && <p className="alert" role="alert">{error}</p>}
            <div className="intro-actions">
              <button type="button" className="btn primary" onClick={() => begin(0)} disabled={opening}>
                গল্পটি শুরু করো
              </button>
              <button type="button" className="btn ghost" onClick={() => begin(0, true)}>
                Skip Intro
              </button>
              {(audioBroken || error) && (
                <>
                  <button type="button" className="btn ghost" onClick={retryAudio}>
                    গান আবার লোড করো
                  </button>
                  <button type="button" className="btn ghost" onClick={watchSilently}>
                    গান ছাড়া দেখো
                  </button>
                </>
              )}
            </div>
          </div>
        )}

        {phase === "loading" && (
          <div className="loader" role="status">
            <SealMark className="load-seal" />
            <h1>PROSTAB</h1>
            <p>গল্পের পাতা সাজানো হচ্ছে...</p>
            <p className="load-note">{loadNote}</p>
            <div className="load-bar" aria-hidden>
              <span />
            </div>
          </div>
        )}
      </section>

      <aside className="side side-right">
        <p className="side-kicker">দৃশ্য</p>
        <nav aria-label="ডেস্কটপ দৃশ্যতালিকা">
          {SCENES.map((item, i) => (
            <button key={item.id} type="button" className={phase === "story" && i === snap.scene ? "is-on" : ""} onClick={() => goScene(i)}>
              <span>{bnDigits(i + 1).padStart(2, "০")}</span>
              {item.title}
            </button>
          ))}
        </nav>
      </aside>

      <p className="sr-only" aria-live="polite">
        {phase === "loading" ? "গল্পের পাতা সাজানো হচ্ছে" : snap.lyric >= 0 ? LYRICS[snap.lyric].text : scene.title}
      </p>
    </main>
  );
}

function StoryLyrics({
  sceneId,
  lyric,
  word,
  prevLyric,
  ended,
  onReplay,
}: {
  sceneId: SceneId;
  lyric: number;
  word: number;
  prevLyric: number;
  ended: boolean;
  onReplay: () => void;
}) {
  const paper = isPaperScene(sceneId);
  if (sceneId === "finale") {
    return (
      <div className="lyrics is-paper finale">
        <div className="poem">
          {LYRICS.map((line, i) =>
            i === lyric ? (
              <Words key={line.startTime} text={line.text} active={word} />
            ) : (
              <p key={line.startTime} className={`line poem-line${i < lyric ? " is-on" : ""}`}>
                {line.text}
              </p>
            ),
          )}
        </div>
        <footer className={`credits${ended ? " is-ended" : ""}`}>
          <p className="wordmark">PROSTAB</p>
          <p className="tag">A story written with feelings.</p>
          <p className="by">ISHMAM</p>
          <button type="button" className="btn primary" onClick={onReplay}>
            আবার দেখো
          </button>
        </footer>
      </div>
    );
  }

  if (lyric < 0) return null;
  const line = LYRICS[lyric];
  return (
    <div className={`lyrics${paper ? " is-paper" : " is-caption"} ${sceneId}`}>
      {prevLyric >= 0 && (
        <div className="lyric-layer is-leaving" aria-hidden>
          <Words text={LYRICS[prevLyric].text} active={99} />
        </div>
      )}
      <div key={line.startTime} className="lyric-layer is-current">
        <Words text={line.text} active={word} />
      </div>
    </div>
  );
}

function Player({
  seekRef,
  timeRef,
  durRef,
  playing,
  muted,
  volume,
  duration,
  buffering,
  onSeekStart,
  onSeek,
  onSeekEnd,
  onToggle,
  onReplay,
  onMute,
  onVolume,
  onChapters,
  onFs,
  full,
}: {
  seekRef: RefObject<HTMLInputElement | null>;
  timeRef: RefObject<HTMLSpanElement | null>;
  durRef: RefObject<HTMLSpanElement | null>;
  playing: boolean;
  muted: boolean;
  volume: number;
  duration: number;
  buffering: boolean;
  onSeekStart: () => void;
  onSeek: (value: number) => void;
  onSeekEnd: () => void;
  onToggle: () => void;
  onReplay: () => void;
  onMute: () => void;
  onVolume: (value: number) => void;
  onChapters: () => void;
  onFs: () => void;
  full: boolean;
}) {
  return (
    <section className="player" aria-label="সঙ্গীত">
      <div className="album" aria-hidden>
        <SealMark className="album-seal" />
        <span className={`eq${playing ? " is-on" : ""}`}>
          <i />
          <i />
          <i />
          <i />
        </span>
      </div>
      <div className="player-copy">
        <p className="player-title">একটি ছোট্ট গল্প</p>
        <p className="player-sub">{buffering ? "বাফার হচ্ছে…" : "PROSTAB"}</p>
      </div>
      <div className="seek-row">
        <span ref={timeRef} className="time">
          0:00
        </span>
        <input
          ref={seekRef}
          className="seek"
          type="range"
          min={0}
          max={duration}
          step={0.01}
          defaultValue={0}
          aria-label="গানের সময়"
          onPointerDown={onSeekStart}
          onPointerUp={onSeekEnd}
          onKeyUp={onSeekEnd}
          onInput={(e) => onSeek(Number(e.currentTarget.value))}
        />
        <span ref={durRef} className="time">
          {formatTime(duration)}
        </span>
      </div>
      <div className="ctrl-row">
        <button type="button" className="icon-btn play" aria-label={playing ? "বিরতি" : "চালু"} aria-pressed={playing} onClick={onToggle}>
          {playing ? <Pause /> : <Play />}
        </button>
        <button type="button" className="icon-btn" aria-label="আবার শুরু" onClick={onReplay}>
          <RotateCcw />
        </button>
        <button type="button" className="icon-btn" aria-label={muted ? "শব্দ চালু" : "শব্দ বন্ধ"} aria-pressed={muted} onClick={onMute}>
          {muted || volume === 0 ? <VolumeX /> : <Volume2 />}
        </button>
        <input
          className="vol"
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={muted ? 0 : volume}
          aria-label="ভলিউম"
          onChange={(e) => onVolume(Number(e.currentTarget.value))}
        />
        <button type="button" className="icon-btn mobile-chap" aria-label="দৃশ্যতালিকা" onClick={onChapters}>
          <List />
        </button>
        <button type="button" className="icon-btn" aria-label={full ? "ফুলস্ক্রিন বন্ধ" : "ফুলস্ক্রিন"} onClick={onFs}>
          {full ? <Minimize2 /> : <Maximize />}
        </button>
      </div>
    </section>
  );
}
