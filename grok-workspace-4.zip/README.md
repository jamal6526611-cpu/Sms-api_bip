# PROSTAB 2.0

A cinematic Bengali romantic short film, played inside the browser.

Music is the provided track. Eight lyric lines appear on the original timestamps and are never rewritten. Thirteen illustrated scenes follow that same clock.

## What you can do

- **গল্পটি শুরু করো** — open the letter and start the music.
- **Skip Intro** — go straight into the story.
- Play, pause, seek, replay, volume, and mute from the glass player.
- Move between scenes with the arrows, the chapter list, or a horizontal swipe.
- Fullscreen, and the keyboard: Space play/pause, Left/Right scenes, Up/Down volume, M mute, F fullscreen, R replay.

Creator credit: ISHMAM.
